/******************************************************************************
*
******************************************************************************/

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using NationalInstruments.DAQmx;
using NationalInstruments.Examples;
using System.IO;
using System.Collections.Generic;

namespace NationalInstruments.Examples.ContGenVoltageWfm_IntClk
{
    /// <summary>
    /// Summary description for MainForm.
    /// </summary>
    public class MainForm : System.Windows.Forms.Form
    {
        private System.Windows.Forms.Button stopButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.GroupBox channelParametersGroupBox;
        private System.Windows.Forms.Label maximumLabel;
        private System.Windows.Forms.Label minimumLabel;
        private System.Windows.Forms.Label physicalChannelLabel;
        private System.Windows.Forms.TextBox maximumTextBox;
        private System.Windows.Forms.TextBox minimumTextBox;
        private System.Windows.Forms.GroupBox functionGeneratorGroupBox;
        protected ComboBox signalTypeComboBox;
        private System.Windows.Forms.Label frequencyLabel;
        internal System.Windows.Forms.Label amplitudeLabel;
        private Task myTask;
        private Task myTask2;
        private Task AnalogOutput7200bps;
        private System.Windows.Forms.NumericUpDown samplesPerBufferNumeric;
        private System.Windows.Forms.Label samplesperBufferLabel;
        private System.Windows.Forms.NumericUpDown cyclesPerBufferNumeric;
        internal System.Windows.Forms.NumericUpDown amplitudeNumeric;
        private System.Windows.Forms.GroupBox timingParametersGroupBox;
        private System.Windows.Forms.Label cyclesPerBufferLabel;
        private System.Windows.Forms.Label signalTypeLabel;
        private System.Windows.Forms.NumericUpDown frequencyNumeric;
        private System.Windows.Forms.Timer statusCheckTimer;
        private System.Windows.Forms.ComboBox physicalChannelComboBox;
        private Button button1;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private string fileNameRead;
        internal Label label1;
        internal NumericUpDown numericUpDown1;
        private TextBox filePathReadTextBox;
        private System.ComponentModel.IContainer components;
        private StreamReader fileStreamReader;
        private BinaryReader fileBinaryReader;
        private Button browseReadButton;
        private OpenFileDialog openFileDialog1;
        private ToolTip toolTip1;
        private bool useTextFileRead;
        private RadioButton radioButton3;
        private TextBox textBox1;
        public List<double> data_base = new List<double>();

        public MainForm()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();
            //
            // TODO: Add any constructor code after InitializeComponent call
            //
            FunctionGenerator.InitComboBox(signalTypeComboBox);

            physicalChannelComboBox.Items.AddRange(DaqSystem.Local.GetPhysicalChannels(PhysicalChannelTypes.AO, PhysicalChannelAccess.External));
            if (physicalChannelComboBox.Items.Count > 0)
                physicalChannelComboBox.SelectedIndex = 0;
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if (components != null) 
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.stopButton = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.timingParametersGroupBox = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.frequencyNumeric = new System.Windows.Forms.NumericUpDown();
            this.frequencyLabel = new System.Windows.Forms.Label();
            this.channelParametersGroupBox = new System.Windows.Forms.GroupBox();
            this.physicalChannelComboBox = new System.Windows.Forms.ComboBox();
            this.physicalChannelLabel = new System.Windows.Forms.Label();
            this.maximumTextBox = new System.Windows.Forms.TextBox();
            this.minimumTextBox = new System.Windows.Forms.TextBox();
            this.maximumLabel = new System.Windows.Forms.Label();
            this.minimumLabel = new System.Windows.Forms.Label();
            this.functionGeneratorGroupBox = new System.Windows.Forms.GroupBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.amplitudeLabel = new System.Windows.Forms.Label();
            this.amplitudeNumeric = new System.Windows.Forms.NumericUpDown();
            this.samplesPerBufferNumeric = new System.Windows.Forms.NumericUpDown();
            this.cyclesPerBufferLabel = new System.Windows.Forms.Label();
            this.cyclesPerBufferNumeric = new System.Windows.Forms.NumericUpDown();
            this.signalTypeLabel = new System.Windows.Forms.Label();
            this.signalTypeComboBox = new System.Windows.Forms.ComboBox();
            this.samplesperBufferLabel = new System.Windows.Forms.Label();
            this.statusCheckTimer = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.filePathReadTextBox = new System.Windows.Forms.TextBox();
            this.browseReadButton = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.timingParametersGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.frequencyNumeric)).BeginInit();
            this.channelParametersGroupBox.SuspendLayout();
            this.functionGeneratorGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.amplitudeNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.samplesPerBufferNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cyclesPerBufferNumeric)).BeginInit();
            this.SuspendLayout();
            // 
            // stopButton
            // 
            this.stopButton.Enabled = false;
            this.stopButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.stopButton.Location = new System.Drawing.Point(184, 414);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(80, 24);
            this.stopButton.TabIndex = 1;
            this.stopButton.Text = "Stop";
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // startButton
            // 
            this.startButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.startButton.Location = new System.Drawing.Point(70, 414);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(80, 24);
            this.startButton.TabIndex = 0;
            this.startButton.Text = "Start";
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // timingParametersGroupBox
            // 
            this.timingParametersGroupBox.Controls.Add(this.radioButton3);
            this.timingParametersGroupBox.Controls.Add(this.radioButton2);
            this.timingParametersGroupBox.Controls.Add(this.radioButton1);
            this.timingParametersGroupBox.Controls.Add(this.frequencyNumeric);
            this.timingParametersGroupBox.Controls.Add(this.frequencyLabel);
            this.timingParametersGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.timingParametersGroupBox.Location = new System.Drawing.Point(46, 150);
            this.timingParametersGroupBox.Name = "timingParametersGroupBox";
            this.timingParametersGroupBox.Size = new System.Drawing.Size(285, 64);
            this.timingParametersGroupBox.TabIndex = 3;
            this.timingParametersGroupBox.TabStop = false;
            this.timingParametersGroupBox.Text = "Timing Parameters";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(217, 47);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(41, 17);
            this.radioButton3.TabIndex = 12;
            this.radioButton3.Text = "File";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(120, 47);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(91, 17);
            this.radioButton2.TabIndex = 10;
            this.radioButton2.Text = "Square Wave";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(24, 47);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(78, 17);
            this.radioButton1.TabIndex = 9;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Sine Wave";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // frequencyNumeric
            // 
            this.frequencyNumeric.Location = new System.Drawing.Point(120, 19);
            this.frequencyNumeric.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.frequencyNumeric.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.frequencyNumeric.Name = "frequencyNumeric";
            this.frequencyNumeric.Size = new System.Drawing.Size(112, 20);
            this.frequencyNumeric.TabIndex = 1;
            this.frequencyNumeric.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // frequencyLabel
            // 
            this.frequencyLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.frequencyLabel.Location = new System.Drawing.Point(15, 21);
            this.frequencyLabel.Name = "frequencyLabel";
            this.frequencyLabel.Size = new System.Drawing.Size(88, 16);
            this.frequencyLabel.TabIndex = 0;
            this.frequencyLabel.Text = "Frequency (Hz):";
            // 
            // channelParametersGroupBox
            // 
            this.channelParametersGroupBox.Controls.Add(this.physicalChannelComboBox);
            this.channelParametersGroupBox.Controls.Add(this.physicalChannelLabel);
            this.channelParametersGroupBox.Controls.Add(this.maximumTextBox);
            this.channelParametersGroupBox.Controls.Add(this.minimumTextBox);
            this.channelParametersGroupBox.Controls.Add(this.maximumLabel);
            this.channelParametersGroupBox.Controls.Add(this.minimumLabel);
            this.channelParametersGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.channelParametersGroupBox.Location = new System.Drawing.Point(46, 14);
            this.channelParametersGroupBox.Name = "channelParametersGroupBox";
            this.channelParametersGroupBox.Size = new System.Drawing.Size(247, 128);
            this.channelParametersGroupBox.TabIndex = 2;
            this.channelParametersGroupBox.TabStop = false;
            this.channelParametersGroupBox.Text = "Channel Parameters";
            // 
            // physicalChannelComboBox
            // 
            this.physicalChannelComboBox.Location = new System.Drawing.Point(120, 24);
            this.physicalChannelComboBox.Name = "physicalChannelComboBox";
            this.physicalChannelComboBox.Size = new System.Drawing.Size(112, 21);
            this.physicalChannelComboBox.TabIndex = 1;
            this.physicalChannelComboBox.Text = "Dev1/ao0";
            // 
            // physicalChannelLabel
            // 
            this.physicalChannelLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.physicalChannelLabel.Location = new System.Drawing.Point(16, 26);
            this.physicalChannelLabel.Name = "physicalChannelLabel";
            this.physicalChannelLabel.Size = new System.Drawing.Size(96, 16);
            this.physicalChannelLabel.TabIndex = 0;
            this.physicalChannelLabel.Text = "Physical Channel:";
            // 
            // maximumTextBox
            // 
            this.maximumTextBox.Location = new System.Drawing.Point(120, 96);
            this.maximumTextBox.Name = "maximumTextBox";
            this.maximumTextBox.Size = new System.Drawing.Size(112, 20);
            this.maximumTextBox.TabIndex = 5;
            this.maximumTextBox.Text = "10";
            // 
            // minimumTextBox
            // 
            this.minimumTextBox.Location = new System.Drawing.Point(120, 60);
            this.minimumTextBox.Name = "minimumTextBox";
            this.minimumTextBox.Size = new System.Drawing.Size(112, 20);
            this.minimumTextBox.TabIndex = 3;
            this.minimumTextBox.Text = "-10";
            // 
            // maximumLabel
            // 
            this.maximumLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.maximumLabel.Location = new System.Drawing.Point(16, 98);
            this.maximumLabel.Name = "maximumLabel";
            this.maximumLabel.Size = new System.Drawing.Size(112, 16);
            this.maximumLabel.TabIndex = 4;
            this.maximumLabel.Text = "Maximum Value (V):";
            // 
            // minimumLabel
            // 
            this.minimumLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.minimumLabel.Location = new System.Drawing.Point(16, 62);
            this.minimumLabel.Name = "minimumLabel";
            this.minimumLabel.Size = new System.Drawing.Size(104, 16);
            this.minimumLabel.TabIndex = 2;
            this.minimumLabel.Text = "Minimum Value (V):";
            // 
            // functionGeneratorGroupBox
            // 
            this.functionGeneratorGroupBox.Controls.Add(this.numericUpDown1);
            this.functionGeneratorGroupBox.Controls.Add(this.label1);
            this.functionGeneratorGroupBox.Controls.Add(this.amplitudeLabel);
            this.functionGeneratorGroupBox.Controls.Add(this.amplitudeNumeric);
            this.functionGeneratorGroupBox.Controls.Add(this.samplesPerBufferNumeric);
            this.functionGeneratorGroupBox.Controls.Add(this.cyclesPerBufferLabel);
            this.functionGeneratorGroupBox.Controls.Add(this.cyclesPerBufferNumeric);
            this.functionGeneratorGroupBox.Controls.Add(this.signalTypeLabel);
            this.functionGeneratorGroupBox.Controls.Add(this.signalTypeComboBox);
            this.functionGeneratorGroupBox.Controls.Add(this.samplesperBufferLabel);
            this.functionGeneratorGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.functionGeneratorGroupBox.Location = new System.Drawing.Point(45, 220);
            this.functionGeneratorGroupBox.Name = "functionGeneratorGroupBox";
            this.functionGeneratorGroupBox.Size = new System.Drawing.Size(266, 188);
            this.functionGeneratorGroupBox.TabIndex = 4;
            this.functionGeneratorGroupBox.TabStop = false;
            this.functionGeneratorGroupBox.Text = "Function Generator Parameters";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DecimalPlaces = 1;
            this.numericUpDown1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown1.Location = new System.Drawing.Point(120, 160);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(112, 20);
            this.numericUpDown1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label1.Location = new System.Drawing.Point(16, 160);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Offset:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // amplitudeLabel
            // 
            this.amplitudeLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.amplitudeLabel.Location = new System.Drawing.Point(17, 126);
            this.amplitudeLabel.Name = "amplitudeLabel";
            this.amplitudeLabel.Size = new System.Drawing.Size(56, 16);
            this.amplitudeLabel.TabIndex = 6;
            this.amplitudeLabel.Text = "Amplitude:";
            // 
            // amplitudeNumeric
            // 
            this.amplitudeNumeric.DecimalPlaces = 1;
            this.amplitudeNumeric.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.amplitudeNumeric.Location = new System.Drawing.Point(120, 126);
            this.amplitudeNumeric.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.amplitudeNumeric.Name = "amplitudeNumeric";
            this.amplitudeNumeric.Size = new System.Drawing.Size(112, 20);
            this.amplitudeNumeric.TabIndex = 7;
            this.amplitudeNumeric.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // samplesPerBufferNumeric
            // 
            this.samplesPerBufferNumeric.Location = new System.Drawing.Point(120, 96);
            this.samplesPerBufferNumeric.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.samplesPerBufferNumeric.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.samplesPerBufferNumeric.Name = "samplesPerBufferNumeric";
            this.samplesPerBufferNumeric.Size = new System.Drawing.Size(112, 20);
            this.samplesPerBufferNumeric.TabIndex = 5;
            this.samplesPerBufferNumeric.Value = new decimal(new int[] {
            250,
            0,
            0,
            0});
            // 
            // cyclesPerBufferLabel
            // 
            this.cyclesPerBufferLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cyclesPerBufferLabel.Location = new System.Drawing.Point(16, 61);
            this.cyclesPerBufferLabel.Name = "cyclesPerBufferLabel";
            this.cyclesPerBufferLabel.Size = new System.Drawing.Size(103, 16);
            this.cyclesPerBufferLabel.TabIndex = 2;
            this.cyclesPerBufferLabel.Text = "Cycles Per Buffer:";
            // 
            // cyclesPerBufferNumeric
            // 
            this.cyclesPerBufferNumeric.Location = new System.Drawing.Point(120, 59);
            this.cyclesPerBufferNumeric.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.cyclesPerBufferNumeric.Name = "cyclesPerBufferNumeric";
            this.cyclesPerBufferNumeric.Size = new System.Drawing.Size(112, 20);
            this.cyclesPerBufferNumeric.TabIndex = 3;
            this.cyclesPerBufferNumeric.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // signalTypeLabel
            // 
            this.signalTypeLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.signalTypeLabel.Location = new System.Drawing.Point(16, 26);
            this.signalTypeLabel.Name = "signalTypeLabel";
            this.signalTypeLabel.Size = new System.Drawing.Size(87, 16);
            this.signalTypeLabel.TabIndex = 0;
            this.signalTypeLabel.Text = "Waveform Type:";
            this.signalTypeLabel.Visible = false;
            // 
            // signalTypeComboBox
            // 
            this.signalTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.signalTypeComboBox.ItemHeight = 13;
            this.signalTypeComboBox.Items.AddRange(new object[] {
            "Sine Wave",
            "Square Wave"});
            this.signalTypeComboBox.Location = new System.Drawing.Point(121, 24);
            this.signalTypeComboBox.Name = "signalTypeComboBox";
            this.signalTypeComboBox.Size = new System.Drawing.Size(112, 21);
            this.signalTypeComboBox.TabIndex = 2;
            this.signalTypeComboBox.Visible = false;
            // 
            // samplesperBufferLabel
            // 
            this.samplesperBufferLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.samplesperBufferLabel.Location = new System.Drawing.Point(16, 98);
            this.samplesperBufferLabel.Name = "samplesperBufferLabel";
            this.samplesperBufferLabel.Size = new System.Drawing.Size(112, 16);
            this.samplesperBufferLabel.TabIndex = 4;
            this.samplesperBufferLabel.Text = "Samples Per Buffer:";
            // 
            // statusCheckTimer
            // 
            this.statusCheckTimer.Tick += new System.EventHandler(this.statusCheckTimer_Tick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(317, 239);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // filePathReadTextBox
            // 
            this.filePathReadTextBox.Location = new System.Drawing.Point(310, 196);
            this.filePathReadTextBox.Name = "filePathReadTextBox";
            this.filePathReadTextBox.ReadOnly = true;
            this.filePathReadTextBox.Size = new System.Drawing.Size(264, 20);
            this.filePathReadTextBox.TabIndex = 9;
            this.filePathReadTextBox.Text = "Choose file location";
            this.filePathReadTextBox.TextChanged += new System.EventHandler(this.filePathReadTextBox_TextChanged);
            // 
            // browseReadButton
            // 
            this.browseReadButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.browseReadButton.Location = new System.Drawing.Point(580, 193);
            this.browseReadButton.Name = "browseReadButton";
            this.browseReadButton.Size = new System.Drawing.Size(24, 23);
            this.browseReadButton.TabIndex = 11;
            this.browseReadButton.Text = "...";
            this.browseReadButton.Click += new System.EventHandler(this.browseReadButton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "rpenFileDialog";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(357, 133);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 12;
            this.textBox1.Text = "1000";
            this.textBox1.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(614, 453);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.browseReadButton);
            this.Controls.Add(this.filePathReadTextBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.functionGeneratorGroupBox);
            this.Controls.Add(this.stopButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.timingParametersGroupBox);
            this.Controls.Add(this.channelParametersGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Continuous Voltage Generation - Int Clk";
            this.timingParametersGroupBox.ResumeLayout(false);
            this.timingParametersGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.frequencyNumeric)).EndInit();
            this.channelParametersGroupBox.ResumeLayout(false);
            this.channelParametersGroupBox.PerformLayout();
            this.functionGeneratorGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.amplitudeNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.samplesPerBufferNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cyclesPerBufferNumeric)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() 
        {
            Application.EnableVisualStyles();
            Application.DoEvents();
            Application.Run(new MainForm());
        }

        private void startButton_Click(object sender, System.EventArgs e)
        {

            if (radioButton1.Checked)
            {

           
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                // create the task and channel
                myTask = new Task();
                myTask.AOChannels.CreateVoltageChannel(physicalChannelComboBox.Text,
                    "",
                    Convert.ToDouble(minimumTextBox.Text), 
                    Convert.ToDouble(maximumTextBox.Text),
                    AOVoltageUnits.Volts);

                // verify the task before doing the waveform calculations
                myTask.Control(TaskAction.Verify);

                // calculate some waveform parameters and generate data
                FunctionGenerator fGen = new FunctionGenerator(
                    myTask.Timing,
                    frequencyNumeric.Value.ToString(),
                    samplesPerBufferNumeric.Value.ToString(),
                    cyclesPerBufferNumeric.Value.ToString(),
                    signalTypeComboBox.Text,
                    amplitudeNumeric.Value.ToString() ,
                      (double)numericUpDown1.Value);
                
                // configure the sample clock with the calculated rate
                myTask.Timing.ConfigureSampleClock("",
                    fGen.ResultingSampleClockRate,
                    SampleClockActiveEdge.Rising,
                    SampleQuantityMode.ContinuousSamples, 1000);


                AnalogSingleChannelWriter writer = 
                    new AnalogSingleChannelWriter(myTask.Stream);

                //write data to buffer
                writer.WriteMultiSample(false,fGen.Data);
                
                //start writing out data
                myTask.Start();
                
                startButton.Enabled = false;
                stopButton.Enabled = true;

                statusCheckTimer.Enabled = true;
            }
            catch(DaqException err)
            {
                statusCheckTimer.Enabled = false;
                MessageBox.Show(err.Message);
                myTask.Dispose();
            }
            Cursor.Current = Cursors.Default;

            }
            else if (radioButton2.Checked)
            {

                AnalogOutput7200bps = new Task();
                double freq = (double)frequencyNumeric.Value;
                double samplesPerBuffer = (double)samplesPerBufferNumeric.Value;
                double cyclesPerBuffer = (double)cyclesPerBufferNumeric.Value;
 
                string analogOut = physicalChannelComboBox.Text;// physicalChannelComboBox.Text;
                AnalogOutput7200bps.AOChannels.CreateVoltageChannel(analogOut, "", Convert.ToDouble(minimumTextBox.Text), Convert.ToDouble(maximumTextBox.Text), AOVoltageUnits.Volts);
                AnalogOutput7200bps.Control(TaskAction.Verify);
                SquareWave square = new SquareWave(AnalogOutput7200bps.Timing, freq, (int)samplesPerBuffer, (int)cyclesPerBuffer, (double)amplitudeNumeric.Value, (double)numericUpDown1.Value);
                AnalogOutput7200bps.Timing.ConfigureSampleClock("", square.ResultingSampleClockRate, SampleClockActiveEdge.Rising, SampleQuantityMode.ContinuousSamples, square.Data.Length);
                AnalogSingleChannelWriter writer = new AnalogSingleChannelWriter(AnalogOutput7200bps.Stream);
                writer.WriteMultiSample(true, square.Data);
                startButton.Enabled = false;
                stopButton.Enabled = true;

            }
            else
            {
                myTask2 = new Task();
                myTask2.AOChannels.CreateVoltageChannel(physicalChannelComboBox.Text,
                    "",
                    Convert.ToDouble(minimumTextBox.Text),
                    Convert.ToDouble(maximumTextBox.Text),
                    AOVoltageUnits.Volts);

                // verify the task before doing the waveform calculations
                myTask2.Control(TaskAction.Verify);
                AnalogSingleChannelWriter writer =
                new AnalogSingleChannelWriter(myTask2.Stream);
                double myrate;
                myrate = (Convert.ToDouble(data_base.Count) * (Convert.ToDouble(frequencyNumeric.Value) / 1)) / Convert.ToDouble(cyclesPerBufferNumeric.Value);
               //Convert.ToInt32(textBox1.Text)
                myTask2.Timing.ConfigureSampleClock("",
           myrate,
              SampleClockActiveEdge.Rising,
              SampleQuantityMode.ContinuousSamples, Convert.ToInt32(samplesPerBufferNumeric.Value));
                writer.WriteMultiSample(false, data_base.ToArray());
                myTask2.Start();

                startButton.Enabled = false;
                stopButton.Enabled = true;
            }
        }
        
        private void stopButton_Click(object sender, System.EventArgs e)
        {
            statusCheckTimer.Enabled = false;
            if (myTask != null)
            {
                try
                {
                    myTask.Stop();
                }
                catch(Exception x)
                {
                    MessageBox.Show(x.Message);
                }
                myTask.Dispose();
                myTask = null;
                startButton.Enabled = true;
                stopButton.Enabled = false;
            }
            if (myTask2 != null)
            {
                try
                {
                    myTask2.Stop();
                }
                catch (Exception x)
                {
                    MessageBox.Show(x.Message);
                }
                myTask2.Dispose();
                myTask2 = null;
                startButton.Enabled = true;
                stopButton.Enabled = false;
            }
            if (AnalogOutput7200bps != null)
            {
                try
                {
                    AnalogOutput7200bps.Stop();
                }
                catch (Exception x)
                {
                    MessageBox.Show(x.Message);
                }
                AnalogOutput7200bps.Dispose();
                AnalogOutput7200bps = null;
                startButton.Enabled = true;
                stopButton.Enabled = false;
            }
        }

        private void statusCheckTimer_Tick(object sender, System.EventArgs e)
        {
            try
            {
                // Getting myTask.IsDone also checks for errors that would prematurely
                // halt the continuous generation.
                if (myTask.IsDone)
                {
                    statusCheckTimer.Enabled = false;
                    myTask.Stop();
                    myTask.Dispose();
                    startButton.Enabled = true;
                    stopButton.Enabled = false;
                }
            }
            catch (DaqException ex)
            {
                statusCheckTimer.Enabled = false;
                System.Windows.Forms.MessageBox.Show(ex.Message);
                myTask.Dispose();
                startButton.Enabled = true;
                stopButton.Enabled = false;
            }
        }
         
            
        
        private void button1_Click(object sender, EventArgs e)
        {
             
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            signalTypeComboBox.Text = "Square Wave";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void filePathReadTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void browseReadButton_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                fileNameRead = openFileDialog1.FileName;
                filePathReadTextBox.Text = fileNameRead;
                toolTip1.SetToolTip(filePathReadTextBox, fileNameRead);
               
                foreach (var line in File.ReadLines(fileNameRead))
                {
                    data_base.Add(Convert.ToDouble(line));
                }
            }
        }
    }
}
