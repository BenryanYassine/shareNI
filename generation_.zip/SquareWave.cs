﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NationalInstruments.DAQmx;
namespace NationalInstruments.Examples.ContGenVoltageWfm_IntClk
{
    public class SquareWave
    {
        private double[] data;
        private double desiredSampleClockRate;
        private double resultingFrequency;
        private double resultingSampleClockRate;
        private double samplesPerCycle;
        private double amplitude;
        private double offset; 
        public SquareWave(Timing timingObject, double frequency, int samplesPerBuffer, int cyclesPerBuffer, double amplitude , double offset )
        {
            timingObject.SampleTimingType = SampleTimingType.SampleClock;
            desiredSampleClockRate = (frequency * samplesPerBuffer) / cyclesPerBuffer;
            samplesPerCycle = samplesPerBuffer / cyclesPerBuffer;
            timingObject.SampleClockRate = desiredSampleClockRate;
            resultingSampleClockRate = timingObject.SampleClockRate;
            resultingFrequency = resultingSampleClockRate / (samplesPerBuffer / cyclesPerBuffer);
            data = GeneratePoints(resultingFrequency, resultingSampleClockRate, samplesPerBuffer, samplesPerCycle, amplitude, offset);

        }



        public double[] Data
        {
            get
            {
                return data;
            }
        }

        public double ResultingSampleClockRate
        {
            get
            {
                return resultingSampleClockRate;
            }
        }


        public double[] GeneratePoints(double frequency, double sampleClockRate, double samplesPerBuffer, double samplesPerCycle, double amplitude, double offset)
        {
            int i;
            int j;
             
            double deltaT = 1 / sampleClockRate;
            int intSamplesPerBuffer = (int)samplesPerBuffer;
            int mid = (int)samplesPerCycle / 2;
            double[] dataVal = new double[intSamplesPerBuffer];

            for (i = 0; i < intSamplesPerBuffer; i++)
            {
                j = i % (int)samplesPerCycle;
                
                dataVal[i] = (amplitude*(1 - 2 * (j / mid)))+offset;
            }

            return dataVal;

        }
    }
}
