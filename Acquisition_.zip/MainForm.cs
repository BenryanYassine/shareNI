/******************************************************************************

******************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Windows.Forms;
using NationalInstruments.DAQmx;
using System.Windows.Forms.DataVisualization.Charting;
using System.Threading;
using System.IO;
using System.Diagnostics;


//using System.Threading.Tasks;

namespace NationalInstruments.Examples.ContAcqVoltageSamples_IntClk_ToFile
{
  


    public class MainForm : System.Windows.Forms.Form
    {
        double[] Values = new double[3];
        private Task myTask;
        private AnalogMultiChannelReader analogInReader;
        private Task runningTask;
        private AsyncCallback analogCallback;
        private double[,] data;
        private DataColumn[] dataColumn = null;
        private DataTable dataTable = null;
        private ArrayList savedData;
        private StreamWriter fileStreamWriter;
        private BinaryWriter fileBinaryWriter;
        private StreamReader fileStreamReader;
        private BinaryReader fileBinaryReader;
        private string fileNameWrite;
        private string fileNameRead;
        private bool useTextFileWrite;
        private bool useTextFileRead;
        private System.Windows.Forms.GroupBox channelParametersGroupBox;
        private System.Windows.Forms.Label maximumLabel;
        private System.Windows.Forms.Label minimumLabel;
        private System.Windows.Forms.Label physicalChannelLabel;
        private System.Windows.Forms.Label rateLabel;       
        private System.Windows.Forms.Label samplesLabel;
        private System.Windows.Forms.Label resultLabel;

        private System.Windows.Forms.GroupBox timingParametersGroupBox;
        private System.Windows.Forms.GroupBox acquisitionResultGroupBox;
        private System.Windows.Forms.DataGrid acquisitionDataGrid;
        private System.Windows.Forms.NumericUpDown rateNumeric;
        private System.Windows.Forms.NumericUpDown samplesPerChannelNumeric;
        private System.Windows.Forms.NumericUpDown minimumValueNumeric;
        private System.Windows.Forms.NumericUpDown maximumValueNumeric;
        private System.Windows.Forms.ComboBox physicalChannelComboBox;
        private System.Windows.Forms.SaveFileDialog writeToFileSaveFileDialog;
        private System.Windows.Forms.OpenFileDialog readFromFileOpenFileDialog;
        private System.Windows.Forms.GroupBox writeToFileGroupBox;
        private System.Windows.Forms.ToolTip fileToolTip;
        private System.Windows.Forms.TextBox filePathWriteTextBox;
        private System.Windows.Forms.Button browseWriteButton;
        private System.Windows.Forms.Label filePathWriteLabel;
        private System.Windows.Forms.RadioButton binaryFileWriteRadioButton;
        private System.Windows.Forms.RadioButton textFileWriteRadioButton;
        private System.Windows.Forms.Label fileTypeWriteLabel;
        private System.Windows.Forms.Button stopButton;
        private System.Windows.Forms.Button startButton;
        private Button button1;
        private System.ComponentModel.IContainer components;
        private ComboBox comboBox1;
        private Label label1;
       public  List<Device> detectedDevices = new List<Device>();
        public List<string> devices_list = new List<string>();
        private GroupBox groupBox1;
        private Label label2;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label7;
        private Label label8;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private Button button2;
        public List<MyClass> devices_base = new List<MyClass>();
        private Label label12;
        public System.Windows.Forms.DataVisualization.Charting.Series series = new System.Windows.Forms.DataVisualization.Charting.Series();
        private Button button4;
        public double thedata;
        public Thread t, t2;
        private TextBox textBox1;
        private Label label13;
        private Label label14;
        private Button button5;
        private Button button3;
        private Label label15;
        private Label label16;
        private Button button6;
        private Button button7;
        public Boolean draw, logout;
        private Chart chart2;
        private Button button9;
        private TextBox textBox2;
        private Button button10;
        private Button button8;
        public List<Double> vals = new List<Double>();
        double[] vals_ = new double[400];
        private Button button11;
        private Button button12;
        private Button button13;
        private NumericUpDown numericUpDown1;
        private NumericUpDown numericUpDown2;
        int vals_i = 0;
        readonly Stopwatch sw = new Stopwatch() ;
        private Label label17;
        private NumericUpDown numericUpDown3;
        double tiiime = 0;
        //public MyClass[] someList = new MyClass[3];
        public MainForm()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();
            Array.Clear(vals_,0,100);
            
            //
            // TODO: Add any constructor code after InitializeComponent call
            //
            stopButton.Enabled = false;
            dataTable= new DataTable();

            ///  physicalChannelComboBox.Items.AddRange(DaqSystem.Local.GetPhysicalChannels(PhysicalChannelTypes.AI, PhysicalChannelAccess.External));
            /// if (physicalChannelComboBox.Items.Count > 0)
            /// physicalChannelComboBox.SelectedIndex = 0;
            /// 
            MyClass NI_9411 = new MyClass("","",1, 1, 1, 1, 1);
            NI_9411.name = "NI 9411";
            NI_9411.type = "DigitalIO";
            NI_9411.number_channels = 6;
            NI_9411.max_rate = 2000000;
            NI_9411.min_rate = 0.1;
            NI_9411.min_vols = 5;
            NI_9411.max_vols = 24;
           
            MyClass NI_9222 = new MyClass("", "", 1, 1, 1, 1, 1);
            NI_9222.name = "NI 9215 (BNC)";
            NI_9222.type = "AnalogInput";
            NI_9222.number_channels = 4;
            NI_9222.max_rate = 230000;
            NI_9222.min_rate = 0.1;
            NI_9222.min_vols = -10;
            NI_9222.max_vols = 10;

            MyClass NI_9260 = new MyClass("", "", 1, 1, 1, 1, 1);
            NI_9260.name = "NI 9260 (BNC)";
            NI_9260.type = "AnalogOutput";
            NI_9260.number_channels = 2;
            NI_9260.max_rate = 51200;
            NI_9260.min_rate = 1612.9032;
            NI_9260.min_vols = -4.2426;
            NI_9260.max_vols = 4.2426;


            devices_base.Add(NI_9222);
            devices_base.Add(NI_9411);
            devices_base.Add(NI_9260);

        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if (components != null) 
                {
                    components.Dispose();
                }
                if (myTask != null)
                {
                    runningTask = null;
                    myTask.Dispose();
                }
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.channelParametersGroupBox = new System.Windows.Forms.GroupBox();
            this.physicalChannelComboBox = new System.Windows.Forms.ComboBox();
            this.minimumValueNumeric = new System.Windows.Forms.NumericUpDown();
            this.maximumValueNumeric = new System.Windows.Forms.NumericUpDown();
            this.maximumLabel = new System.Windows.Forms.Label();
            this.minimumLabel = new System.Windows.Forms.Label();
            this.physicalChannelLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.timingParametersGroupBox = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rateNumeric = new System.Windows.Forms.NumericUpDown();
            this.rateLabel = new System.Windows.Forms.Label();
            this.samplesLabel = new System.Windows.Forms.Label();
            this.samplesPerChannelNumeric = new System.Windows.Forms.NumericUpDown();
            this.acquisitionResultGroupBox = new System.Windows.Forms.GroupBox();
            this.resultLabel = new System.Windows.Forms.Label();
            this.acquisitionDataGrid = new System.Windows.Forms.DataGrid();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.filePathWriteTextBox = new System.Windows.Forms.TextBox();
            this.writeToFileSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.readFromFileOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.fileToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.writeToFileGroupBox = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.stopButton = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.browseWriteButton = new System.Windows.Forms.Button();
            this.filePathWriteLabel = new System.Windows.Forms.Label();
            this.binaryFileWriteRadioButton = new System.Windows.Forms.RadioButton();
            this.textFileWriteRadioButton = new System.Windows.Forms.RadioButton();
            this.fileTypeWriteLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button2 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.channelParametersGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minimumValueNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maximumValueNumeric)).BeginInit();
            this.timingParametersGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rateNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.samplesPerChannelNumeric)).BeginInit();
            this.acquisitionResultGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.acquisitionDataGrid)).BeginInit();
            this.writeToFileGroupBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.SuspendLayout();
            // 
            // channelParametersGroupBox
            // 
            this.channelParametersGroupBox.Controls.Add(this.physicalChannelComboBox);
            this.channelParametersGroupBox.Controls.Add(this.minimumValueNumeric);
            this.channelParametersGroupBox.Controls.Add(this.maximumValueNumeric);
            this.channelParametersGroupBox.Controls.Add(this.maximumLabel);
            this.channelParametersGroupBox.Controls.Add(this.minimumLabel);
            this.channelParametersGroupBox.Controls.Add(this.physicalChannelLabel);
            this.channelParametersGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.channelParametersGroupBox.Location = new System.Drawing.Point(8, 137);
            this.channelParametersGroupBox.Name = "channelParametersGroupBox";
            this.channelParametersGroupBox.Size = new System.Drawing.Size(224, 120);
            this.channelParametersGroupBox.TabIndex = 0;
            this.channelParametersGroupBox.TabStop = false;
            this.channelParametersGroupBox.Text = "Channel Parameters";
            // 
            // physicalChannelComboBox
            // 
            this.physicalChannelComboBox.Location = new System.Drawing.Point(120, 24);
            this.physicalChannelComboBox.Name = "physicalChannelComboBox";
            this.physicalChannelComboBox.Size = new System.Drawing.Size(96, 21);
            this.physicalChannelComboBox.TabIndex = 1;
            // 
            // minimumValueNumeric
            // 
            this.minimumValueNumeric.DecimalPlaces = 2;
            this.minimumValueNumeric.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.minimumValueNumeric.Location = new System.Drawing.Point(120, 56);
            this.minimumValueNumeric.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.minimumValueNumeric.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            -2147483648});
            this.minimumValueNumeric.Name = "minimumValueNumeric";
            this.minimumValueNumeric.Size = new System.Drawing.Size(96, 20);
            this.minimumValueNumeric.TabIndex = 3;
            this.minimumValueNumeric.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147418112});
            // 
            // maximumValueNumeric
            // 
            this.maximumValueNumeric.DecimalPlaces = 2;
            this.maximumValueNumeric.Location = new System.Drawing.Point(120, 88);
            this.maximumValueNumeric.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.maximumValueNumeric.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            -2147483648});
            this.maximumValueNumeric.Name = "maximumValueNumeric";
            this.maximumValueNumeric.Size = new System.Drawing.Size(96, 20);
            this.maximumValueNumeric.TabIndex = 5;
            this.maximumValueNumeric.Value = new decimal(new int[] {
            100,
            0,
            0,
            65536});
            // 
            // maximumLabel
            // 
            this.maximumLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.maximumLabel.Location = new System.Drawing.Point(16, 88);
            this.maximumLabel.Name = "maximumLabel";
            this.maximumLabel.Size = new System.Drawing.Size(112, 16);
            this.maximumLabel.TabIndex = 4;
            this.maximumLabel.Text = "Maximum Value (V):";
            // 
            // minimumLabel
            // 
            this.minimumLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.minimumLabel.Location = new System.Drawing.Point(16, 56);
            this.minimumLabel.Name = "minimumLabel";
            this.minimumLabel.Size = new System.Drawing.Size(104, 15);
            this.minimumLabel.TabIndex = 2;
            this.minimumLabel.Text = "Minimum Value (V):";
            // 
            // physicalChannelLabel
            // 
            this.physicalChannelLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.physicalChannelLabel.Location = new System.Drawing.Point(16, 26);
            this.physicalChannelLabel.Name = "physicalChannelLabel";
            this.physicalChannelLabel.Size = new System.Drawing.Size(96, 16);
            this.physicalChannelLabel.TabIndex = 0;
            this.physicalChannelLabel.Text = "Physical Channel:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 53);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Scan";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timingParametersGroupBox
            // 
            this.timingParametersGroupBox.Controls.Add(this.label1);
            this.timingParametersGroupBox.Controls.Add(this.rateNumeric);
            this.timingParametersGroupBox.Controls.Add(this.rateLabel);
            this.timingParametersGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.timingParametersGroupBox.Location = new System.Drawing.Point(8, 263);
            this.timingParametersGroupBox.Name = "timingParametersGroupBox";
            this.timingParametersGroupBox.Size = new System.Drawing.Size(224, 76);
            this.timingParametersGroupBox.TabIndex = 1;
            this.timingParametersGroupBox.TabStop = false;
            this.timingParametersGroupBox.Text = "Timing Parameters";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(117, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "label1";
            // 
            // rateNumeric
            // 
            this.rateNumeric.DecimalPlaces = 2;
            this.rateNumeric.Location = new System.Drawing.Point(120, 19);
            this.rateNumeric.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.rateNumeric.Name = "rateNumeric";
            this.rateNumeric.Size = new System.Drawing.Size(96, 20);
            this.rateNumeric.TabIndex = 3;
            this.rateNumeric.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // rateLabel
            // 
            this.rateLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.rateLabel.Location = new System.Drawing.Point(16, 21);
            this.rateLabel.Name = "rateLabel";
            this.rateLabel.Size = new System.Drawing.Size(56, 16);
            this.rateLabel.TabIndex = 2;
            this.rateLabel.Text = "Rate (Hz):";
            // 
            // samplesLabel
            // 
            this.samplesLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.samplesLabel.Location = new System.Drawing.Point(187, 348);
            this.samplesLabel.Name = "samplesLabel";
            this.samplesLabel.Size = new System.Drawing.Size(104, 16);
            this.samplesLabel.TabIndex = 0;
            this.samplesLabel.Text = "Samples/Channel:";
            this.samplesLabel.Visible = false;
            // 
            // samplesPerChannelNumeric
            // 
            this.samplesPerChannelNumeric.Location = new System.Drawing.Point(291, 346);
            this.samplesPerChannelNumeric.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.samplesPerChannelNumeric.Name = "samplesPerChannelNumeric";
            this.samplesPerChannelNumeric.Size = new System.Drawing.Size(96, 20);
            this.samplesPerChannelNumeric.TabIndex = 1;
            this.samplesPerChannelNumeric.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.samplesPerChannelNumeric.Visible = false;
            // 
            // acquisitionResultGroupBox
            // 
            this.acquisitionResultGroupBox.Controls.Add(this.resultLabel);
            this.acquisitionResultGroupBox.Controls.Add(this.acquisitionDataGrid);
            this.acquisitionResultGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.acquisitionResultGroupBox.Location = new System.Drawing.Point(240, 137);
            this.acquisitionResultGroupBox.Name = "acquisitionResultGroupBox";
            this.acquisitionResultGroupBox.Size = new System.Drawing.Size(304, 186);
            this.acquisitionResultGroupBox.TabIndex = 3;
            this.acquisitionResultGroupBox.TabStop = false;
            this.acquisitionResultGroupBox.Text = "Acquisition Results";
            // 
            // resultLabel
            // 
            this.resultLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.resultLabel.Location = new System.Drawing.Point(8, 16);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(112, 16);
            this.resultLabel.TabIndex = 0;
            this.resultLabel.Text = "Acquisition Data (V):";
            // 
            // acquisitionDataGrid
            // 
            this.acquisitionDataGrid.AllowSorting = false;
            this.acquisitionDataGrid.DataMember = "";
            this.acquisitionDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.acquisitionDataGrid.Location = new System.Drawing.Point(6, 32);
            this.acquisitionDataGrid.Name = "acquisitionDataGrid";
            this.acquisitionDataGrid.ParentRowsVisible = false;
            this.acquisitionDataGrid.ReadOnly = true;
            this.acquisitionDataGrid.Size = new System.Drawing.Size(274, 170);
            this.acquisitionDataGrid.TabIndex = 1;
            this.acquisitionDataGrid.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.Location = new System.Drawing.Point(15, 26);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(173, 21);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // filePathWriteTextBox
            // 
            this.filePathWriteTextBox.Location = new System.Drawing.Point(120, 57);
            this.filePathWriteTextBox.Name = "filePathWriteTextBox";
            this.filePathWriteTextBox.ReadOnly = true;
            this.filePathWriteTextBox.Size = new System.Drawing.Size(384, 20);
            this.filePathWriteTextBox.TabIndex = 4;
            this.filePathWriteTextBox.Text = "Choose file location";
            // 
            // writeToFileSaveFileDialog
            // 
            this.writeToFileSaveFileDialog.CreatePrompt = true;
            this.writeToFileSaveFileDialog.DefaultExt = "txt";
            this.writeToFileSaveFileDialog.FileName = "acquisitionData.txt";
            this.writeToFileSaveFileDialog.Filter = "Text Files|*.txt| All Files|*.*";
            this.writeToFileSaveFileDialog.Title = "Save Acquisition Data To File";
            // 
            // readFromFileOpenFileDialog
            // 
            this.readFromFileOpenFileDialog.DefaultExt = "txt";
            this.readFromFileOpenFileDialog.FileName = "acquisitionData.txt";
            this.readFromFileOpenFileDialog.Filter = "Text Files|*.txt| All Files|*.*";
            this.readFromFileOpenFileDialog.Title = "Open Acquisition Data";
            // 
            // writeToFileGroupBox
            // 
            this.writeToFileGroupBox.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.writeToFileGroupBox.Controls.Add(this.button5);
            this.writeToFileGroupBox.Controls.Add(this.stopButton);
            this.writeToFileGroupBox.Controls.Add(this.startButton);
            this.writeToFileGroupBox.Controls.Add(this.browseWriteButton);
            this.writeToFileGroupBox.Controls.Add(this.filePathWriteLabel);
            this.writeToFileGroupBox.Controls.Add(this.binaryFileWriteRadioButton);
            this.writeToFileGroupBox.Controls.Add(this.textFileWriteRadioButton);
            this.writeToFileGroupBox.Controls.Add(this.filePathWriteTextBox);
            this.writeToFileGroupBox.Controls.Add(this.fileTypeWriteLabel);
            this.writeToFileGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.writeToFileGroupBox.Location = new System.Drawing.Point(8, 372);
            this.writeToFileGroupBox.Name = "writeToFileGroupBox";
            this.writeToFileGroupBox.Size = new System.Drawing.Size(536, 120);
            this.writeToFileGroupBox.TabIndex = 2;
            this.writeToFileGroupBox.TabStop = false;
            this.writeToFileGroupBox.Text = "Write To File";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(383, 88);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(42, 23);
            this.button5.TabIndex = 8;
            this.button5.Text = "Info";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // stopButton
            // 
            this.stopButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.stopButton.Location = new System.Drawing.Point(216, 88);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(80, 24);
            this.stopButton.TabIndex = 7;
            this.stopButton.Text = "Stop";
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // startButton
            // 
            this.startButton.Enabled = false;
            this.startButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.startButton.Location = new System.Drawing.Point(120, 88);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(80, 24);
            this.startButton.TabIndex = 6;
            this.startButton.Text = "Start";
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // browseWriteButton
            // 
            this.browseWriteButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.browseWriteButton.Location = new System.Drawing.Point(504, 56);
            this.browseWriteButton.Name = "browseWriteButton";
            this.browseWriteButton.Size = new System.Drawing.Size(24, 23);
            this.browseWriteButton.TabIndex = 5;
            this.browseWriteButton.Text = "...";
            this.browseWriteButton.Click += new System.EventHandler(this.browseWriteButton_Click);
            // 
            // filePathWriteLabel
            // 
            this.filePathWriteLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.filePathWriteLabel.Location = new System.Drawing.Point(16, 59);
            this.filePathWriteLabel.Name = "filePathWriteLabel";
            this.filePathWriteLabel.Size = new System.Drawing.Size(72, 16);
            this.filePathWriteLabel.TabIndex = 3;
            this.filePathWriteLabel.Text = "File Path:";
            // 
            // binaryFileWriteRadioButton
            // 
            this.binaryFileWriteRadioButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.binaryFileWriteRadioButton.Location = new System.Drawing.Point(192, 24);
            this.binaryFileWriteRadioButton.Name = "binaryFileWriteRadioButton";
            this.binaryFileWriteRadioButton.Size = new System.Drawing.Size(72, 16);
            this.binaryFileWriteRadioButton.TabIndex = 2;
            this.binaryFileWriteRadioButton.Visible = false;
            this.binaryFileWriteRadioButton.CheckedChanged += new System.EventHandler(this.binaryFileWriteRadioButton_CheckedChanged);
            // 
            // textFileWriteRadioButton
            // 
            this.textFileWriteRadioButton.Checked = true;
            this.textFileWriteRadioButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.textFileWriteRadioButton.Location = new System.Drawing.Point(120, 24);
            this.textFileWriteRadioButton.Name = "textFileWriteRadioButton";
            this.textFileWriteRadioButton.Size = new System.Drawing.Size(72, 16);
            this.textFileWriteRadioButton.TabIndex = 1;
            this.textFileWriteRadioButton.TabStop = true;
            this.textFileWriteRadioButton.Text = "Text File";
            this.textFileWriteRadioButton.CheckedChanged += new System.EventHandler(this.textFileWriteRadioButton_CheckedChanged);
            // 
            // fileTypeWriteLabel
            // 
            this.fileTypeWriteLabel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.fileTypeWriteLabel.Location = new System.Drawing.Point(16, 24);
            this.fileTypeWriteLabel.Name = "fileTypeWriteLabel";
            this.fileTypeWriteLabel.Size = new System.Drawing.Size(72, 16);
            this.fileTypeWriteLabel.TabIndex = 0;
            this.fileTypeWriteLabel.Text = "File Type:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chart2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.button12);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(12, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(530, 100);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Infos";
            // 
            // chart2
            // 
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(434, 93);
            this.chart2.Name = "chart2";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart2.Series.Add(series1);
            this.chart2.Size = new System.Drawing.Size(300, 300);
            this.chart2.TabIndex = 20;
            this.chart2.Text = "chart2";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(458, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 13);
            this.label11.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(458, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 13);
            this.label10.TabIndex = 18;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(461, 0);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(56, 23);
            this.button12.TabIndex = 29;
            this.button12.Text = "IN";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(285, 74);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 13);
            this.label9.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(285, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(285, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 13);
            this.label8.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(376, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Min Voltage:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(376, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Max Voltage:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(201, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Min Rate:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(202, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Max Rate:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(203, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Fonction: ";
            // 
            // chart1
            // 
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(575, 22);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            this.chart1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(678, 300);
            this.chart1.TabIndex = 10;
            this.chart1.Text = "chart1";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(840, 328);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "Draw Data";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(509, 331);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "label12";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(852, 441);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 13;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(666, 331);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 14;
            this.textBox1.Text = "500";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(715, 310);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 13);
            this.label13.TabIndex = 15;
            this.label13.Text = "Points";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(547, 153);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "Data";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(542, 428);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 23);
            this.button3.TabIndex = 17;
            this.button3.Text = "Create Default";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(572, 334);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "Points to draw :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(772, 334);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 13);
            this.label16.TabIndex = 19;
            this.label16.Text = "Samples";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(1009, 441);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 20;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Visible = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(605, 477);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 21;
            this.button7.Text = "writer";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(1216, 334);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 23;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Visible = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(1206, 389);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 24;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(975, 404);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 25;
            this.textBox2.Text = "0";
            this.textBox2.Visible = false;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(840, 348);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 26;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Visible = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(473, 10);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(56, 22);
            this.button11.TabIndex = 28;
            this.button11.Text = "Out";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(725, 9);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 21;
            this.button13.Text = "Scale";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(617, 13);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(48, 20);
            this.numericUpDown1.TabIndex = 22;
            this.numericUpDown1.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(671, 13);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            -2147483648});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(48, 20);
            this.numericUpDown2.TabIndex = 30;
            this.numericUpDown2.Value = new decimal(new int[] {
            10,
            0,
            0,
            -2147483648});
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(668, 372);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 13);
            this.label17.TabIndex = 9;
            this.label17.Text = "label17";
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.DecimalPlaces = 2;
            this.numericUpDown3.Location = new System.Drawing.Point(32, 331);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(96, 20);
            this.numericUpDown3.TabIndex = 31;
            this.numericUpDown3.Value = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.numericUpDown3.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(1370, 512);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.samplesLabel);
            this.Controls.Add(this.samplesPerChannelNumeric);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.writeToFileGroupBox);
            this.Controls.Add(this.acquisitionResultGroupBox);
            this.Controls.Add(this.timingParametersGroupBox);
            this.Controls.Add(this.channelParametersGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Volatge Acquisition ";
            this.channelParametersGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.minimumValueNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maximumValueNumeric)).EndInit();
            this.timingParametersGroupBox.ResumeLayout(false);
            this.timingParametersGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rateNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.samplesPerChannelNumeric)).EndInit();
            this.acquisitionResultGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.acquisitionDataGrid)).EndInit();
            this.writeToFileGroupBox.ResumeLayout(false);
            this.writeToFileGroupBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() 
        {
            Application.EnableVisualStyles();
            Application.DoEvents();
            Application.Run(new MainForm());
        }

        private void browseWriteButton_Click(object sender, System.EventArgs e)
        {
            if (textFileWriteRadioButton.Checked) 
            {
                useTextFileWrite = true;
                writeToFileSaveFileDialog.DefaultExt = "*.txt";
                writeToFileSaveFileDialog.FileName = "acquisitionData.txt";
                writeToFileSaveFileDialog.Filter = "Text Files|*.txt|All Files|*.*";
            }
            else
            {
                useTextFileWrite = false;
                writeToFileSaveFileDialog.DefaultExt = "*.bin";
                writeToFileSaveFileDialog.FileName = "acquisitionData.bin";
                writeToFileSaveFileDialog.Filter = "Binary Files|*.bin|All Files|*.*";
            }

            // Display Save File Dialog (Windows forms control)
            DialogResult result = writeToFileSaveFileDialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                fileNameWrite = writeToFileSaveFileDialog.FileName;
                filePathWriteTextBox.Text = fileNameWrite;
                fileToolTip.SetToolTip(filePathWriteTextBox, fileNameWrite);
                startButton.Enabled = true;
            }
        }

        private void browseReadButton_Click(object sender, System.EventArgs e)
        {
           
        }

        private void startButton_Click(object sender, System.EventArgs e)
        {
            if (runningTask == null)
            {
                try 
                {   
                    // Create a new file for data
                   
                    int i = 0;
                    //Create a virtual channel
                    for (i = 0; i < devices_base.Count; i++)
                    {
                        if( devices_base[i].name == detectedDevices[comboBox1.SelectedIndex].ProductType)
                        {

                            if (devices_base[i].type == "AnalogInput" )
                            {
                                bool opened = CreateDataFile();
                                if (!opened)
                                {
                                    return;
                                }

                                // Modify the UI
                                stopButton.Enabled = true;
                                startButton.Enabled = false;

                                //Create a new task
                                myTask = new Task();
                                myTask.AIChannels.CreateVoltageChannel(physicalChannelComboBox.Text, "",
                        (AITerminalConfiguration)(-1), Convert.ToDouble(minimumValueNumeric.Value),
                        Convert.ToDouble(maximumValueNumeric.Value), AIVoltageUnits.Volts);
                                //myTask.DIChannels.CreateChannel(physicalChannelComboBox.Text, "jd",ChannelLineGrouping.OneChannelForAllLines);
                               
                            }
                            else
                            {
                                MessageBox.Show("Duplicate username and password");
                         
                                goto finish;

                            }
                         

                        }
                        

                     }

                    
                
                    //Configure the timing parameters
                    myTask.Timing.ConfigureSampleClock("", Convert.ToDouble(rateNumeric.Value),
                        SampleClockActiveEdge.Rising, SampleQuantityMode.ContinuousSamples, Convert.ToInt32(numericUpDown3.Value));
                    //   myTask.Timing.ConfigureSampleClock("", Convert.ToDouble(rateNumeric.Value),
                    //   SampleClockActiveEdge.Rising, SampleQuantityMode.FiniteSamples, Convert.ToInt32(numericUpDown3.Value));

                    //Verify the Task
                    myTask.Control(TaskAction.Verify);

                    //Prepare the table and file for Data
                    String[] channelNames = new String[myTask.AIChannels.Count];
                     i = 0;
                    foreach (AIChannel a in myTask.AIChannels)
                    {
                        channelNames[i++] = a.PhysicalName;
                    }

                    InitializeDataTable(channelNames, ref dataTable); 
                    acquisitionDataGrid.DataSource = dataTable;   

                    // Add the channel names (and any other information) to the file
                    int samples = Convert.ToInt32(samplesPerChannelNumeric.Value);
                    PrepareFileForData();
                    savedData = new ArrayList();
                    for (i = 0; i < myTask.AIChannels.Count; i++)
                    {
                         savedData.Add(new ArrayList());
                    }
                    
                    runningTask = myTask;
                    analogInReader= new AnalogMultiChannelReader(myTask.Stream);

                    // Use SynchronizeCallbacks to specify that the object 
                    // marshals callbacks across threads appropriately.
                    analogInReader.SynchronizeCallbacks = true;
                    
                    analogCallback = new AsyncCallback(AnalogInCallback);
                           
                    analogInReader.BeginReadMultiSample(samples, analogCallback, myTask);
                    sw.Start(); 
                  


                }
                catch (DaqException exception)
                {
                    //Display Errors
                    MessageBox.Show(exception.Message);
                    runningTask=null;
                    myTask.Dispose();
                    stopButton.Enabled = false;
                    startButton.Enabled = true;
                    writeToFileGroupBox.Enabled = true;
                }           
            }

            finish:
            Console.WriteLine("End of start.");
             


        }

        public   void ThreadProc()
        {
            int val = 0;
            while (true) {
             //val =  (savedData[0] as ArrayList).Count;
                if (draw) {
                    val++;
                    if (chart1.InvokeRequired)
                    {
                        tiiime++;
                   //     chart1.Invoke(new MethodInvoker(delegate { chart1.Series[0].Points.Add(thedata);}));
                        chart1.Invoke(new MethodInvoker(delegate { chart1.Series[0].Points.Add(thedata); }));
                        // vat time = sw.Elapsed;
                        //  chart1.Invoke(new MethodInvoker(delegate { formsPlot1.Render(); }));

                      

                        draw = false;

                    }
                    

                    if ( val  >= Convert.ToInt32(textBox1.Text))
                        { 
                    
                    
                    // Thread.Sleep(1000);
                    if (chart1.InvokeRequired)
                    {
                       // chart1.Invoke(new MethodInvoker(delegate { chart1.Series[0].Points.Clear(); }));
                            chart1.Invoke(new MethodInvoker(delegate { chart1.Series[0].Points.RemoveAt(0); }));

                          

                            val = Convert.ToInt32(textBox1.Text);
                        
                    }
                    else
                    {
                      //  chart1.Series[0].Points.Clear();
                    }
                   
                  //  Thread.Sleep(500);
                }
                if (label1.InvokeRequired)
                {
                    label1.Invoke(new MethodInvoker(delegate {  label1.Text= Convert.ToString(val); }));
                }

                // label1.Text = Convert.ToString(val);


            }
            Thread.Sleep(0);
            }
        }

        private void AnalogInCallback(IAsyncResult ar)
        {
           
            try
            {
                if (runningTask != null && runningTask == ar.AsyncState)
                {
                    //Read the available data from the channels
                    data = analogInReader.EndReadMultiSample(ar);
                  //chart1.Series[0].Points.Add(data[0,0]);
                  //  val = (savedData[0] as ArrayList).Count;
                    //  if (val >= Convert.ToInt32(textBox1.Text))
                    //  {
                    //  Thread.Sleep(1000);
                    //  chart1.Series[0].Points.Clear();
                    // Thread.Sleep(500);
                    //   }
                    thedata = data[0, 0];
                    //   Array.Copy(vals_, 1, vals_, 0, vals_.Length - 1);
                    //  vals_[vals_.Length - 1] = data[0, 0];

                    /*
                    if (vals_i < vals_.Length)
                    {
                        vals_[vals_i] = thedata;
                        vals_i += 1;

                    }
                    else
                    {
                        
                        Array.Copy(vals_, 1, vals_, 0, vals_.Length - 1);
                        vals_[vals_.Length - 1] = data[0, 0];
                        formsPlot1.Render();
                     //   vals_i = 0;
                    }
                    */
                    label17.Text = sw.Elapsed.ToString();

                    draw = true;
                    logout = true;
                    //Plot your data here
                    //Displays data in grid and writes to file
                     DisplayData(data, ref dataTable);
                  chart1.Series[0].Points.Add(thedata);

                    LogData(data);
                  if (chart1.Series[0].Points.Count >= Convert.ToInt32(textBox1.Text))
                     {
                    chart1.Series[0].Points.RemoveAt(0);
                  }
                       analogInReader.BeginReadMultiSample(Convert.ToInt32(samplesPerChannelNumeric.Value),
                    analogCallback, myTask);
                }
            }
            catch(DaqException exception)
            {   
                //Display Errors
                MessageBox.Show(exception.Message);
                runningTask = null;
                myTask.Dispose();
                stopButton.Enabled = false;
                startButton.Enabled = true;
             }
        }

        private void stopButton_Click(object sender, System.EventArgs e)
        {
            if (runningTask != null)
            {
                //Dispose of the task
                CloseFile();

                runningTask = null;
                myTask.Dispose();
                stopButton.Enabled = false;
                startButton.Enabled = true;
                writeToFileGroupBox.Enabled = true;
            }
        }

        
        

        private void DisplayData(double[,] sourceArray, ref DataTable dataTable)
        {   
            //Display the first 10 points of the Read/Write in the Datagrid
            try
            {
                int channelCount = sourceArray.GetLength(0);
                int dataCount;
                
                if (sourceArray.GetLength(1) < 10)
                    dataCount = sourceArray.GetLength(1);
                else
                    dataCount = 10;
                
                // Write to Data Table
                for (int i = 0; i < dataCount; i++)             
                {
                    for (int j = 0; j < channelCount; j++)
                    {
                        // Writes data to data table
                        dataTable.Rows[i][j] = sourceArray.GetValue(j, i); 
                    }
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.ToString());
                runningTask = null;
                myTask.Dispose();
                stopButton.Enabled = false;
                startButton.Enabled = true;
                writeToFileGroupBox.Enabled = true;
            }
        }

        private void LogData(double[,] data)
        {
            int channelCount = data.GetLength(0);
            int dataCount = data.GetLength(1);

            for (int i = 0; i < channelCount; i++)
            {
                ArrayList l = savedData[i] as ArrayList;

                for (int j = 0; j < dataCount; j++)
                {
                    l.Add(data[i, j]);
                }
            }
        }

       

        

        private void CloseFile()
        {
            int channelCount = savedData.Count;
            int dataCount = (savedData[0] as ArrayList).Count;

            try
            {
                if (useTextFileWrite)
                {
                   // fileStreamWriter.WriteLine(dataCount.ToString());

                    for (int i = 0; i < dataCount; i++)
                    {
                        for (int j = 0; j < channelCount; j++)
                        {
                            // Writes data to file
                            ArrayList l = savedData[j] as ArrayList;
                            double dataValue = (double)l[i];
                            fileStreamWriter.Write(dataValue.ToString("e6"));
                            fileStreamWriter.Write("\t"); //seperate the data for each channel
                        }
                        fileStreamWriter.WriteLine(); //new line of data (start next scan)
                    }

                    fileStreamWriter.Close();
                }
                else
                {
                    fileBinaryWriter.Write(dataCount.ToString());

                    for (int i = 0; i < dataCount; i++)
                    {
                        for (int j = 0; j < channelCount; j++)
                        {
                            // Writes data to file
                            ArrayList l = savedData[j] as ArrayList;
                            double dataValue = (double)l[i];
                            fileBinaryWriter.Write((double)dataValue);
                        }
                    }

                    fileBinaryWriter.Close();
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.TargetSite.ToString());
                runningTask = null;
                myTask.Dispose();
                stopButton.Enabled = false;
                startButton.Enabled = true;
            }
        }

        public void InitializeDataTable(String[] channelNames, ref DataTable data)
        {
           
            int numChannels = channelNames.GetLength(0);
            data.Rows.Clear();
            data.Columns.Clear();
            dataColumn = new DataColumn[numChannels];
            int numOfRows = 10;

            for (int i = 0; i < numChannels; i++)
            {   
                dataColumn[i] = new DataColumn();
                dataColumn[i].DataType = typeof(double);
                dataColumn[i].ColumnName = channelNames[i];
            }

            data.Columns.AddRange(dataColumn); 

            for (int i = 0; i < numOfRows; i++)             
            {
                object[] rowArr = new object[numChannels];
                data.Rows.Add(rowArr);              
            }
        }

        //Creates a text/binary stream based on the user selections
        private bool CreateDataFile()
        {
            try
            {
                FileStream fs = new FileStream(fileNameWrite, FileMode.Create);
                if (useTextFileWrite)
                {
                    fileStreamWriter = new StreamWriter(fs);
                }
                else
                {
                    fileBinaryWriter = new BinaryWriter(fs);
                }
            }
            catch (System.IO.IOException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }

            return true;
        }

        // Opens a text/binary stream based on the user selections
       

        // Only used by text files to write the channel name
        // Can expand this for binary too
        private void PrepareFileForData()
        {
            //Prepare file for data (Write out the channel names
            int numChannels = myTask.AIChannels.Count;

            if (useTextFileWrite)
            {
                for (int i = 0; i < numChannels; i++)
                {   
                    fileStreamWriter.WriteLine(myTask.AIChannels[i].PhysicalName);
                   //fileStreamWriter.Write("\t");
                    fileStreamWriter.WriteLine(Convert.ToString(samplesPerChannelNumeric.Value));
                  //  fileStreamWriter.Write("\t");
                    fileStreamWriter.WriteLine(Convert.ToString(rateNumeric.Value));
                   // fileStreamWriter.Write("\t");

                }
               // fileStreamWriter.WriteLine();
            }
            else
            {
                for (int i = 0; i < numChannels; i++)
                {   
                    fileBinaryWriter.Write(myTask.AIChannels[i].PhysicalName);
                }
                fileBinaryWriter.Write("\r\n");
            }
        }

        private void textFileWriteRadioButton_CheckedChanged(object sender, System.EventArgs e)
        {
            if (textFileWriteRadioButton.Checked)
            {
                useTextFileWrite = true;
            }
            
            startButton.Enabled = false;
        }

        private void binaryFileWriteRadioButton_CheckedChanged(object sender, System.EventArgs e)
        {
            if (binaryFileWriteRadioButton.Checked)
            {
                useTextFileWrite = false;
            }
            
            startButton.Enabled = false;
        }

        private void textFileReadRadioButton_CheckedChanged(object sender, System.EventArgs e)
        {
           
        }

        private void binaryFileReadRadioButton_CheckedChanged(object sender, System.EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // detectedDevices = new List<Device>();
            string[] devices;
            ProductCategory jj;
            string nj;
            
            devices = DaqSystem.Local.GetPhysicalChannels(PhysicalChannelTypes.AI, PhysicalChannelAccess.External);
            devices = DaqSystem.Local.Devices;
            Device device = DaqSystem.Local.LoadDevice(devices[1]);
            jj = device.ProductCategory;
            

            for (int i = 0; i < devices.Length; i++)
            {
                device = DaqSystem.Local.LoadDevice(devices[i]);
                 
              if(device.ProductCategory != ProductCategory.CompactDaqChassis)
                {
                    detectedDevices.Add(device);
                    comboBox1.Items.Add(device.ProductType);
                    comboBox1.Text = device.ProductType;

                 //   devices = device.GetPhysicalChannels(PhysicalChannelTypes.All, PhysicalChannelAccess.External);
                }
                
            }

        }

      

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        label1.Text = comboBox1.SelectedIndex.ToString();
            label1.Text = detectedDevices[comboBox1.SelectedIndex].ProductType;
            physicalChannelComboBox.Items.Clear();
            physicalChannelComboBox.Items.AddRange(detectedDevices[comboBox1.SelectedIndex].GetPhysicalChannels(PhysicalChannelTypes.AI | PhysicalChannelTypes.DILine | PhysicalChannelTypes.DIPort | PhysicalChannelTypes.DOLine | PhysicalChannelTypes.DOPort | PhysicalChannelTypes.AO , PhysicalChannelAccess.External));
            physicalChannelComboBox.SelectedIndex = 0;
            int i = 0;
            for (i = 0; i < devices_base.Count; i++)
            {
                if (devices_base[i].name == detectedDevices[comboBox1.SelectedIndex].ProductType)
            {

                    label8.Text = devices_base[i].type;
                    label7.Text = devices_base[i].max_rate.ToString();
                    label9.Text = devices_base[i].min_rate.ToString();
                    label10.Text = devices_base[i].max_vols.ToString();
                    label11.Text = devices_base[i].min_vols.ToString();
                   minimumValueNumeric.Value = Convert.ToDecimal(devices_base[i].min_vols); 
                  maximumValueNumeric.Value = Convert.ToDecimal(devices_base[i].max_vols);
                    break;
                }
            }

        }

       
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        { 
            //Form.CheckForIllegalCrossThreadCalls = false;

             

           
            ThreadStart tt = new ThreadStart(ThreadProc);

            t = new Thread(tt);
            
             t.Start();
            

            chart1.ChartAreas[0].Position.Height = 100;
            chart1.ChartAreas[0].Position.Width = 100;


            series.ChartType = SeriesChartType.Line;
            series.Points.Add(2);
            series.Points.Add(6);
            series.Points.Add(1);
           // chart1.Series.Add(series);
            chart1.Series[0].Points.Add(9);
            chart1.Series[0].Points.Add(4);
            chart1.Series[0].Points.Add(3);
            // chart1.Series.;
            
            

        }

        private void button4_Click(object sender, EventArgs e)
        {
             

            Values[0] = 1;
            Values[1] = 2;
            Values[2] = 3;
           
        }

       

        private void button3_Click(object sender, EventArgs e)
        {
            string filename="yass.txt";

            string path = AppDomain.CurrentDomain.BaseDirectory + filename; //System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            filePathWriteTextBox.Text = path;
            if (File.Exists(path))
            {
              File.Delete(path);
              

            }

            var myfile = File.Create(path);
            myfile.Close();
            fileNameWrite = path; 
            startButton.Enabled = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var texttoshow = "Line 1: NameOfTheDevice/PhysicalLine" + Environment.NewLine + "Line 2: Frequency" + Environment.NewLine + "Rest of the lines : Data";
            MessageBox.Show(texttoshow);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            vals_[0] = 3;
            vals_[1] = 2;
            vals_[2] = 1;
            int k = 0;
            k = vals_.Length;
           
        }


        double[] generate_timing(double frequency, double[] data)
        {
            int i = 0;
            double[] timing = new double[data.Length]; ;
            double temp = 1 / frequency;
            timing[0] = 0;
            for (i = 1; i < data.Length; i++)
            {
                timing[i] = timing[i - 1] + temp;


            }

            return timing;
        }

        private void button8_Click(object sender, EventArgs e)
        {
           
           
            chart1.ChartAreas[0].Position.Height = 100;
            chart1.ChartAreas[0].Position.Width = 100;


            series.ChartType = SeriesChartType.Line;
            series.Points.Add(2);
            series.Points.Add(6);
            series.Points.Add(1);
            // chart1.Series.Add(series);
            chart1.Series[0].Points.Add(9);
            chart1.Series[0].Points.Add(4);
            chart1.Series[0].Points.Add(3);
            chart1.Series[0].Points.Add(9);
            chart1.Series[0].Points.Add(4);
            chart1.Series[0].Points.Add(3);
            chart1.Series[0].Points.Add(9);
            chart1.Series[0].Points.Add(4);
            chart1.Series[0].Points.Add(3);
            chart1.Series[0].Points.Add(9);
            chart1.Series[0].Points.Add(4);
            chart1.Series[0].Points.Add(9);
            chart1.Series[0].Points.Add(4);
            chart1.Series[0].Points.Add(3);

            chart1.Series[0].Points.Add(3);
            
           
            //    chart1.Series[0].ChartArea.
            //    chart1.ChartAreas[0].AxisX.MajorGrid.IntervalOffset= 10;
        }

        private void button9_Click(object sender, EventArgs e)
        {
           // chart1.ChartAreas[0].AxisX.IntervalOffset = Convert.ToDouble(textBox2.Text);
           // chart1.ChartAreas[0].AxisX.MajorGrid.IntervalOffset = Convert.ToDouble(textBox2.Text); ;
            chart1.Series[0].Points.RemoveAt(0);
            int i = 0;
            for (i = 0; i < chart1.Series[0].Points.Count; i++)
            {
           //     chart1.Series[0].Points[i].XValue -= 1;
            }
                 
        }

        private void button10_Click(object sender, EventArgs e)
        {
            t.Suspend();
            //t.Abort();
            

        }

        private void button12_Click(object sender, EventArgs e)
        {
            Axis ax = chart1.ChartAreas[0].AxisX;
            ax.ScaleView.Size = double.IsNaN(ax.ScaleView.Size) ?
                                (ax.Maximum - ax.Minimum) / 2 : ax.ScaleView.Size /= 2;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Axis ax = chart1.ChartAreas[0].AxisX;
            ax.ScaleView.Size = double.IsNaN(ax.ScaleView.Size) ?
                                ax.Maximum : ax.ScaleView.Size *= 2;
            if (ax.ScaleView.Size > ax.Maximum - ax.Minimum)
            {
                ax.ScaleView.Size = ax.Maximum;
                ax.ScaleView.Position = 0;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            chart1.ChartAreas[0].AxisY.Maximum = Convert.ToDouble(numericUpDown1.Value);
            chart1.ChartAreas[0].AxisY.Minimum = Convert.ToDouble(numericUpDown2.Value);

        }

        private void writter()
        {
           

            while (true) { 

                if(logout) {
            try
            {

                        FileStream fileStream = new FileStream(
                              "C:/Users/ysn/Pictures/New folder/cours/Project HAMELIN/TP_Automatique_Diagnoistic_Sauter/mpc/sync.txt", FileMode.OpenOrCreate,
                              FileAccess.ReadWrite, FileShare.None);
                        StreamReader streamReader = new StreamReader(fileStream);
                        string currentContents = streamReader.ReadLine();
                        currentContents = streamReader.ReadLine();
                        //streamReader.Close();
                        fileStream.SetLength(0);
                        StreamWriter writer = new StreamWriter(fileStream);
                        if (Convert.ToInt32(currentContents) == 0)
                        {
                       
                        writer.WriteLine(thedata);
                        writer.WriteLine(1);
                        writer.Close();

                        }
                        else
                        {
                            writer.Close();
                        }
                         
                       
                        //   using (StreamWriter writer = new StreamWriter(fileStream))

                        //   {
                        
                        // writer.WriteLine(thedata);

                        //    writer.WriteLine(Convert.ToString(rand.Next(1, 10)));
                        //  writer.WriteLine("eded");


                        logout = false;
                        //     fileStream.Close();
                        //  }
                    }
                    catch (Exception ex)
            {
     // MessageBox.Show("File is in use!! Close it and try again");
                 //MessageBox.Show(ex.Message);

                    }
           


                }
 Thread.Sleep(100);

            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            ThreadStart tt2 = new ThreadStart(writter);
             
            t2 = new Thread(tt2);
         
            t2.Start();
            

        }
    }


    public class MyClass
{
    //  public MyClass[] someList = new MyClass[2];

    public string name { get; set; }
    public string type { get; set; }
    public double max_rate { get; set; }
    public double min_rate { get; set; }
        public double min_vols { get; set; }
        public double max_vols { get; set; }
        
    public int number_channels { get; set; }

        public MyClass(string name, string type, double max_rate , double min_rate , double min_vols , double max_vols, double number_channels)
        {
            this.name = name;
            type = type;
            max_rate = max_rate;
            min_rate = min_rate;
            max_vols = max_vols;
            number_channels = number_channels;
            min_vols = min_vols;
        }

    }

}